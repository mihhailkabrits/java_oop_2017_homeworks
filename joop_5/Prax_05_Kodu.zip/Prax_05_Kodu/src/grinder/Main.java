package grinder;

/**
 * Created by Mihha on 11-Oct-16.
 */
public class Main {

    public static void grind(Grinder grinder) {
        try {
            grinder.grind();
            System.out.println("successful");
        } catch (GrinderNotCleanException e) {
            grinder.clean();
            System.out.println("Machine cleaned, you can now grind coffee.");
        }
    }

    public static void main(String[] args) {
        Grinder g = new Grinder();
        for (int i = 0; i < 100; i++) {
            grind(g);
        }
    }
}
