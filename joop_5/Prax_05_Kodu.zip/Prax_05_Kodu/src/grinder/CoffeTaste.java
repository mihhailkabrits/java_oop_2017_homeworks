package grinder;

/**
 * Created by Mihha on 11-Oct-16.
 */
public class CoffeTaste {
    public String taste;

    public void addTaste(String taste) {
        if ("toffee".equals(taste) || "peppermint".equals(taste) || "vanilla".equals(taste)) {
            this.taste = taste;
        } else {
            throw new FlavourNotAvailable("");
        }
    }
}
