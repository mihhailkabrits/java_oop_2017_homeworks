package grinder;

public class CoffeeMachine {
	public static void main(String[] args) {
		Grinder grinder = new Grinder();
		
		try {
			grinder.grind();
			grinder.grind();
			grinder.grind();
			grinder.enterEnergySaveMode(111);
		} catch (GrinderNotCleanException e) {
			System.err.println("Ouch! " + e.getMessage());
		} catch (IllegalAccessError | IllegalArgumentException e) {
			System.err.println("Auch! " + e.getMessage());
		}
	}
}
