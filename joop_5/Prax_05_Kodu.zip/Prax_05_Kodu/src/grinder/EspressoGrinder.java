package grinder;

public class EspressoGrinder extends Grinder {
	private static final double GRANULARITY = 0.3;
	
	@Override
	public double grind() {
		super.grind();
		return GRANULARITY;
	}
}
