package grinder;

/**
 * Created by Mihha on 11-Oct-16.
 */
public class FlavourNotAvailable extends RuntimeException {

    public FlavourNotAvailable(String message) {
        super(message);
    }
}
