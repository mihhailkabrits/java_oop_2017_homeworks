package grinder;

import java.time.LocalTime;

public class Grinder {

	private static final double GRANULARITY = 1.0;
	private int grindCount = 0;
	private boolean energySavingMode = false;

	public static Grinder makeGrinder(LocalTime time) {
		if (!time.isBefore(LocalTime.of(6, 0)) && !time.isAfter(LocalTime.of(11, 0))) {
			return new EspressoGrinder();
		}
		return new Grinder();
	}

	public double grind() {
		if(grindCount >= 3) {
			throw new GrinderNotCleanException("Please clean!");
		}
		if (isEnergySavingMode()) {
			exitEnergySaveMode();
		}
		grindCount++;
		return GRANULARITY;
	}

	public int getGrindCount() {
		return grindCount ;
	}

	public void clean() {
		grindCount = 0;
	}

	public void enterEnergySaveMode(int minutes) {
		if (minutes < 1 || minutes > 60) {
			throw new IllegalArgumentException("Too long..");
		}
		energySavingMode = true;
	}

	public boolean isEnergySavingMode() {
		return energySavingMode;
	}

	public void exitEnergySaveMode() {
		energySavingMode = false;
	}

}
