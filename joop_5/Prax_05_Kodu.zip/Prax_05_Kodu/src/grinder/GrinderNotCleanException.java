package grinder;

public class GrinderNotCleanException extends RuntimeException{

	public GrinderNotCleanException(String message) {
		super(message);
	}
}
