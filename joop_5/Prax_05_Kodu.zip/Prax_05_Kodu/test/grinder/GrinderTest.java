package grinder;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalTime;

public class GrinderTest {
	
	private Grinder grinder;
	private Grinder espressoGrinder;
	private CoffeTaste ct;

	@Before
	public void runBeforeEachTest() {
		this.grinder = new Grinder();
		this.espressoGrinder = new EspressoGrinder();
		ct = new CoffeTaste();
	}
	
	@Test
	public void testGrindingReturnsGranulation() {
		assertEquals(1.0, grinder.grind(), 0.01);
	}
	
	@Test
	public void testEspressoGrindingReturnsGranulation() {
		assertEquals(0.3, espressoGrinder.grind(), 0.01);
	}
	
	@Test
	public void testNewGrinderCounterReturnsZero() {
		assertEquals(0, grinder.getGrindCount());
	}
	
	@Test
	public void testGrinderCountsCoffee() {
		grinder.grind();
		grinder.grind();
		assertEquals(2, grinder.getGrindCount());
	}
	
	@Test
	public void testCleaningResetsCounter() {
		grinder.grind();
		grinder.grind();
		grinder.clean();
		assertEquals(0, grinder.getGrindCount());
	}

	@Test(expected=GrinderNotCleanException.class)
	public void expectExceptionIfGrinderNotCleaned() {
		grinder.grind();
		grinder.grind();
		grinder.grind();
		grinder.grind();
	}

	@Test(expected=IllegalArgumentException.class)
	public void expectExceptionOnTooLongEnergySaveMode() {
		grinder.enterEnergySaveMode(61);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void expectExceptionOnTooShortEnergySaveMode() {
		grinder.enterEnergySaveMode(0);
	}
	
	@Test
	public void expectNoExceptionOnEnteringEnergySavingMode() {
		grinder.enterEnergySaveMode(1);
		grinder.enterEnergySaveMode(15);
		grinder.enterEnergySaveMode(60);
	}
	
	@Test
	public void newGrinderIsNotInEnergySavingMode() {
		assertFalse(grinder.isEnergySavingMode());
	}
	
	@Test
	public void newGrinderIsInEnergySavingMode() {
		grinder.enterEnergySaveMode(30);
		assertTrue(grinder.isEnergySavingMode());
	}
	
	@Test
	public void checkGrinderExitsFromEnergySavingMode() {
		grinder.enterEnergySaveMode(30);
		grinder.exitEnergySaveMode();
		assertFalse(grinder.isEnergySavingMode());
	}
	
	@Test
	public void grindingExitsEnergySavingMode() {
		grinder.enterEnergySaveMode(30);
		grinder.grind();
		assertFalse(grinder.isEnergySavingMode());
	}

	@Test
	public void makeEarlyEspressoGrinderTest() {
		Grinder g = Grinder.makeGrinder(LocalTime.of(6, 0));
		assertEquals(g.getClass(), EspressoGrinder.class);
		assertNotEquals(g.getClass(), Grinder.class);
	}

	@Test
	public void makeLateEspressoGrinderTest() {
		Grinder g = Grinder.makeGrinder(LocalTime.of(11, 0));
		assertEquals(g.getClass(), EspressoGrinder.class);
		assertNotEquals(g.getClass(), Grinder.class);
	}

	@Test
	public void makeEarlyGrinderTest() {
		Grinder g = Grinder.makeGrinder(LocalTime.of(5, 59));
		assertEquals(g.getClass(), Grinder.class);
		assertNotEquals(g.getClass(), EspressoGrinder.class);
	}

	@Test
	public void makeLateGrinderTest() {
		Grinder g = Grinder.makeGrinder(LocalTime.of(11, 1));
		assertEquals(g.getClass(), Grinder.class);
		assertNotEquals(g.getClass(), EspressoGrinder.class);
	}

	@Test
	public void makeCoffeWithTasteTest() {
		ct.addTaste("vanilla");
		ct.addTaste("toffee");
		ct.addTaste("peppermint");
	}

	@Test (expected = FlavourNotAvailable.class)
	public  void addTasteExceptionOnInvalidInputTest() {
		ct.addTaste("chocolate");
	}
}
