package grinder;

import static org.junit.Assert.*;

/**
 * Created by Mihha on 11-Oct-16.
 */
public class CoffeeMachineTest {

}