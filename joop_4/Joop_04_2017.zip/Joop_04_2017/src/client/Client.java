package client;

import java.time.LocalDate;
import java.util.Optional;

import card.CreditCard;
import card.DebitCard;

public class Client {
    protected long idCode;
    protected CreditCard creditCard;
    protected DebitCard debitCard;
    protected LocalDate dateOfBirth;

    public Client(long idCode, LocalDate dateOfBirth) {
        this.idCode = idCode;
        this.dateOfBirth = dateOfBirth;
    }

    public void addDebitCard(DebitCard card) {
        this.debitCard = card;
    }

    public void addCreditCard(CreditCard card) {
        this.creditCard = card;
    }

    public DebitCard getDebitCard() {
        return debitCard;
    }

    public CreditCard getNullableCreditCard() {
        return creditCard;
    }

    public Optional<CreditCard> getCreditCard() {
        return Optional.ofNullable(creditCard);
    }


    public int monthlyPayment(LocalDate start) {
        LocalDate now = LocalDate.now();

        return getDifferenceInMonths(start, now) * 100;

    }

    protected int getDifferenceInMonths(LocalDate start, LocalDate now) {

        int yearDifference = now.getYear() - start.getYear();
        int monthDifference =  now.getMonthValue() - start.getMonthValue();
        return yearDifference * 12 + monthDifference;
    }
}
