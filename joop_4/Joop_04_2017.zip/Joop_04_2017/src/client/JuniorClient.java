package client;

import java.time.LocalDate;

/**
 * Created by Mihha on 05-Oct-16.
 */
public class JuniorClient extends Client {



    public JuniorClient(long idCode, LocalDate dateOfBirth) {



        super(idCode, dateOfBirth);
    }

    @Override
    public int monthlyPayment(LocalDate start) {
        System.out.println("START" + start);
        LocalDate now = LocalDate.now();
        LocalDate result = now;
        result = result.minusYears(dateOfBirth.getYear());
        System.out.println(result);
        result = result.minusDays(dateOfBirth.getDayOfYear());
        System.out.println(result);
        result = result.minusMonths(dateOfBirth.getMonthValue());
        System.out.println(result);
        int age = result.getYear();
        System.out.println("AGE: " + age);
        return (age) * getDifferenceInMonths(start, now);
    }
}
