package bank;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import card.CreditCard;
import card.DebitCard;
import client.Client;

public class BankClientGateway {

    static Map<Long, Client> clients = new HashMap<>();

    public static Optional<Client> getClientById(long idCode, LocalDate dateOfBirth) {
        LocalDate now = LocalDate.now();
        dateOfBirth = dateOfBirth.plusYears(17);
        System.out.println(dateOfBirth.isAfter(now));
        if (dateOfBirth.isAfter(now)) {
            return Optional.empty();
        }
        if (!clients.containsKey(idCode)) {
            clients.put(idCode, createClient(idCode, dateOfBirth));
        }
        return Optional.of(clients.get(idCode));
    }

    private static Client createClient(long idCode, LocalDate dateOfBirth) {
        if (idCode < 4) {
            throw new IllegalArgumentException("Thrown illegal Argument exeption!");
        } else {
            Client client = new Client(idCode, dateOfBirth);
            client.addDebitCard(new DebitCard());
            decideAndAddBonus(client);
            decideAndCreateCreditCard(idCode, client);
            return client;
        }
    }

    private static void decideAndCreateCreditCard(long idCode, Client client) {
        if (idCode < 80) {
            client.addCreditCard(new CreditCard());
        }
    }

    private static void decideAndAddBonus(Client client) {
        if (clients.size() % 3 == 0) {
            DebitCard debitCard = client.getDebitCard();
            debitCard.depositMoney(new BigDecimal(100));
        }
    }

}
