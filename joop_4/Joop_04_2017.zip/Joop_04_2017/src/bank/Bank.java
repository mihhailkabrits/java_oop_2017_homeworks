package bank;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import card.Card;
import card.CreditCard;
import client.Client;
import client.JuniorClient;

public class Bank {
    public static void main(String[] args) {
        List<Client> clients = Arrays.asList(
//                BankClientGateway.getClientById(1, LocalDate.of(2009, 1, 3)).get()
//                BankClientGateway.getClientById(2, LocalDate.of(2000, 10, 2)).get(),
                BankClientGateway.getClientById(12, LocalDate.of(1990, 10, 3)).get(),
                BankClientGateway.getClientById(99, LocalDate.of(1000, 12, 1)).get(),
                BankClientGateway.getClientById(100, LocalDate.of(100, 1, 3)).get()
        );

        for (Client client : clients) {
            // deebetkaart alati olemas
            client.getDebitCard().makePayment(BigDecimal.ONE);

            Card creditCard = client.getNullableCreditCard();
            if (creditCard != null) {

                creditCard.makePayment(BigDecimal.TEN);
            }

            Optional<CreditCard> creditCardOpt = client.getCreditCard();
            if (creditCardOpt.isPresent()) {
                creditCardOpt.get().makePayment(BigDecimal.TEN);
            }
        }

        JuniorClient junior = new JuniorClient(321432, LocalDate.of(2006, 5, 4));
        System.out.println("JUUNIOR PAYMENT" + junior.monthlyPayment(LocalDate.of(2016, 2, 2)));

    }

}
