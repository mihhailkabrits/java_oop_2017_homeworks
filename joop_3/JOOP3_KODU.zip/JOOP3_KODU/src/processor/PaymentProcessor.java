package processor;

import java.math.BigDecimal;
import java.util.List;

import card.Card;

public class PaymentProcessor {
	
	public void processPayments(List<Card> cards) {
			for (Card card : cards) {
				card.makePayment(new BigDecimal("3.233"));
				System.out.println(card.getBalance());
			}
	}
}
