import java.util.Arrays;

import card.Card;
import card.CreditCard;
import card.DebitCard;
import processor.PaymentProcessor;

public class Bank {
	public static void main(String[] args) {
		Card card = new CreditCard();//.makePayment(BigDecimal.TEN);
		System.out.println(card.getBalance());
		
		PaymentProcessor processor = new PaymentProcessor();
		processor
		.processPayments(Arrays.asList(new DebitCard(), new CreditCard()));
	}
}
