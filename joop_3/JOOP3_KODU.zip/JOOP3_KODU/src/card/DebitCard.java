package card;

import java.math.BigDecimal;

/**
 * Created by Mihha on 21-Sep-16.
 */
public class DebitCard implements Card {
    private BigDecimal balance;

    public DebitCard(){
        balance = new BigDecimal("10000.0005");
    }

    public DebitCard(BigDecimal balance) {
        this.balance = balance;
    }

    @Override
    public BigDecimal getBalance(){
        return balance;

    }

    @Override
    public void makePayment(BigDecimal amount) {
        System.out.println("Makse deebetkaardilt");
        if (checkBalance(amount)) {
            makePaymentCore(amount);
        } else {
            System.out.println("You are too poor!");

        }
    }

    protected boolean checkBalance(BigDecimal amount) {
        // balance <= amount
        if (balance.compareTo(amount) <= 0){
            return false;
        }
        return true;
    }

     public  void setBalance(BigDecimal balance){
         this.balance = balance;
     }

     void makePaymentCore(BigDecimal amount) {
        balance = balance.subtract(amount);
    }

}
