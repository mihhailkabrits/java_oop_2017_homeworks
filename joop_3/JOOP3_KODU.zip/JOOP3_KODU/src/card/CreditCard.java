package card;

import java.math.BigDecimal;
import java.util.Calendar;

/**
 * Created by Mihha on 21-Sep-16.
 */
public class CreditCard extends DebitCard {
    private static final BigDecimal MAX_CREDIT = new BigDecimal(700);

    public CreditCard() {
        super();
    }


    public CreditCard(BigDecimal initialBalance){
            setBalance(initialBalance);
    }
    @Override
    public void makePayment(BigDecimal amount) {
        System.out.println("Makse krediittkaardilt");
        if (checkBalance(amount)) {
            makePaymentCore(amount);
        } else {
            System.out.println("You are too poor!");
        }
    }

    @Override
    protected boolean checkBalance(BigDecimal amount) {
        return super.checkBalance(amount.subtract(MAX_CREDIT));
    }


    public BigDecimal getBalance(Calendar cal) {
        return super.getBalance();
    }
}


