package card;

import java.math.BigDecimal;

/**
 * Created by Mihha on 21-Sep-16.
 */
public interface Card {
    BigDecimal getBalance();
    void makePayment(BigDecimal amount);
}
