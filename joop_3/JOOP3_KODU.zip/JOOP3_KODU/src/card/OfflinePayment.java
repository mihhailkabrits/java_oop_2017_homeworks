package card;

import java.math.BigDecimal;

/**
 * Created by Mihha on 27-Sep-16.
 */
public class OfflinePayment extends DebitCard {
    private static BigDecimal MIN_SINGLE_PAYMENT = new BigDecimal(1);
    private static BigDecimal MAX_SINGLE_PAYMENT = new BigDecimal(50);
    private static BigDecimal MAX_TOTAL_MICROPAYMENTS = new BigDecimal(200);
    private static BigDecimal SERVICE_EXTRA_FEE = new BigDecimal(3);

    public OfflinePayment() {
        super();
    }

    public OfflinePayment(BigDecimal balance) {
        super(balance);
    }

    private BigDecimal micropayments = new BigDecimal(0);

    protected boolean micropaymentsAvailable(BigDecimal amount){
        // amount > MAX PAYMENT -> false
        if(amount.compareTo(MIN_SINGLE_PAYMENT) < 0){
            return false;
        }
        if(amount.compareTo(MAX_SINGLE_PAYMENT) > 0){
            return false;
        }
        return true;
    }
    protected boolean micropaymentsExtraFee(BigDecimal amount){

        if(amount.compareTo(MAX_TOTAL_MICROPAYMENTS) >= 0){
            return false;
        }

        return true;
    }

    public void makeOfflinePayment(BigDecimal amount) {
        System.out.println("Makse Offline");
        if (micropaymentsExtraFee(amount) && micropaymentsAvailable(amount)) {
            makePaymentCore(amount);
            System.out.println("new balance: " + super.getBalance());
        } else if (micropaymentsExtraFee(amount)) {
            makePaymentCore(amount = amount.add(SERVICE_EXTRA_FEE));
            System.out.println("new balance: " + super.getBalance());
        } else {
            System.out.println("You are too poor!");
        }
    }

}
