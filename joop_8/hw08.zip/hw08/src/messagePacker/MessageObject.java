package messagePacker;


public class MessageObject {

    String message;



    public MessageObject(String message) {
        this.message=message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String deleteVowels() {
       return message.replaceAll("[AEIOUaeiou]\\B", "");
    }

}
