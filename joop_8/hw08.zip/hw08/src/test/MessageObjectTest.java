package test;

import org.junit.Test;

import static org.junit.Assert.*;


public class MessageObjectTest {


    @Test

}