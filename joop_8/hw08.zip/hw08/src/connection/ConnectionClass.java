package connection;

import messagePacker.MessageObject;
import sun.plugin2.message.Message;

import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class ConnectionClass {

    MessageObject messageObject;

    public ConnectionClass(MessageObject messageObject) {
        this.messageObject = messageObject;
    }

    String newMessage;

    public void addMessage(String newMessage) {
        this.newMessage = newMessage;
        messageObject.setMessage(messageObject.getMessage() + ";" + newMessage);

    }

    public void packAndSend() {
        try(PrintWriter out = new PrintWriter("teaduskeskus.txt")) {
            out.println(messageObject.deleteVowels());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
