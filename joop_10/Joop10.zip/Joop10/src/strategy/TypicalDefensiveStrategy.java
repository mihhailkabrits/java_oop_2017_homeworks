package strategy;

import robot.MovingMode;
import robot.Robot;

public class TypicalDefensiveStrategy implements RobotStrategy {
    @Override
    public void actWhenBeingAttacked(Robot robot, int attackingRobotHeightInCM, double approachingSpeed) {
        robot.getMotor().setRotationSpeed(1000);
        robot.setMovingMode(MovingMode.SLOW);
    }

    @Override
    public void actWhenEnemyFallingBack(Robot robot, double enemyFallingBackSpeedInRPM) {
        robot.getMotor().setRotationSpeed(0); // STOP!
        robot.setMovingMode(MovingMode.OFF);
    }

    @Override
    public void actWhenDeadEnd(Robot robot) throws InterruptedException {
        new TypicalOffensiveStrategy().actWhenDeadEnd(robot);
    }
}
