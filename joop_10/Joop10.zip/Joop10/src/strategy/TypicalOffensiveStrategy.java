package strategy;

import robot.Robot;
import robot.motors.Motor;

public class TypicalOffensiveStrategy implements RobotStrategy {
    @Override
    public void actWhenBeingAttacked(Robot robot, int attackingRobotHeightInCM, double approachingSpeed) {
        robot.getMotor().setRotationSpeed(attackingRobotHeightInCM < 10 ? 2000 : 1500);
    }

    @Override
    public void actWhenEnemyFallingBack(Robot robot, double enemyFallingBackSpeedInRPM) {
        robot.getMotor().setRotationSpeed(enemyFallingBackSpeedInRPM >= 500 ? Motor.MAXIMUM_ROTATION_SPEED_IN_RTM : 1500);
    }

    @Override
    public void actWhenDeadEnd(Robot robot) throws InterruptedException {
        robot.getMotor().setRotationSpeed(1500);
        Thread.sleep(1000);
        robot.getMotor().setRotationSpeed(300);
        Thread.sleep(100);
        robot.getMotor().setRotationSpeed(2000);
    }
}
