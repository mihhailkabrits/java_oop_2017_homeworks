package strategy;

import robot.Robot;

public interface RobotStrategy {
    void actWhenBeingAttacked(Robot robot, int attackingRobotHeightInCM, double approachingSpeed);

    void actWhenEnemyFallingBack(Robot robot, double enemyFallingBackSpeedInRPM);

    void actWhenDeadEnd(Robot robot) throws InterruptedException;
}
