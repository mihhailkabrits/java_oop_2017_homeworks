package robot.motors;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Motor {
    public static final double MAXIMUM_ROTATION_SPEED_IN_RTM = 10_000;

    private final static Logger LOGGER = Logger.getLogger(Motor.class.getName());
    private double rotationSpeedInRPM;

    static {
        try {
            FileHandler fileHandler = new FileHandler("log.txt");
            fileHandler.setFormatter(new SimpleFormatter());
            LOGGER.addHandler(fileHandler);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setRotationSpeed(double rotationSpeedInRPM) {
        if (rotationSpeedInRPM < 0) {
            throw new IllegalArgumentException("Rotation speed cannot be negative: " + rotationSpeedInRPM);
        }

        if (rotationSpeedInRPM > MAXIMUM_ROTATION_SPEED_IN_RTM) {
            throw new IllegalArgumentException("Rotation speed is more than max: " + rotationSpeedInRPM);
        }

        this.rotationSpeedInRPM = rotationSpeedInRPM;
        LOGGER.setLevel(Level.INFO);
        LOGGER.info(String.format("Speed changed: %.2f rpm", this.rotationSpeedInRPM));
    }
}
