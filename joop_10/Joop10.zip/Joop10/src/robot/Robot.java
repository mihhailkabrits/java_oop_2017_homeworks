package robot;

import robot.motors.Motor;
import strategy.RobotStrategy;

public class Robot {
    private Motor motor;
    private RobotStrategy currentStrategy;
    private MovingMode movingMode;

    public Robot(Motor motor) {
        this.motor = motor;
        this.movingMode = MovingMode.OFF;
    }

    public void actWhenBeingAttacked(int attackingRobotHeight, double approachingSpeed) {
        currentStrategy.actWhenBeingAttacked(this, attackingRobotHeight, approachingSpeed);
    }

    public void actWhenEnemyFallingBack(double enemyFallingBackSpeed) {
        currentStrategy.actWhenEnemyFallingBack(this, enemyFallingBackSpeed);
    }

    public void actWhenDeadEnd() throws InterruptedException {
        currentStrategy.actWhenDeadEnd(this);
    }

    public void setCurrentStrategy(RobotStrategy currentStrategy) {
        this.currentStrategy = currentStrategy;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMovingMode(MovingMode movingMode) {
        this.movingMode = movingMode;
    }

    @Override
    public String toString() {
        return "Robot with " + currentStrategy.getClass().getSimpleName() + " strategy";
    }
}
