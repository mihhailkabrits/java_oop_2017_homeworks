package robot;

public enum MovingMode {
    OFF, SLOW, FAST
}
