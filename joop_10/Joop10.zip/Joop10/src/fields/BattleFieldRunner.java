package fields;

import robot.Robot;
import robot.motors.Motor;
import strategy.TypicalDefensiveStrategy;
import strategy.TypicalOffensiveStrategy;

public class BattleFieldRunner {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("The first robot");
        Robot robot1 = new Robot(new Motor());
        robot1.setCurrentStrategy(new TypicalDefensiveStrategy());
        robot1.actWhenBeingAttacked(999, 999);
        robot1.actWhenEnemyFallingBack(999);
        robot1.actWhenDeadEnd();

        System.out.println("The second robot");
        Robot robot2 = new Robot(new Motor());
        robot2.setCurrentStrategy(new TypicalOffensiveStrategy());
        System.out.println(robot2);

        robot2.actWhenBeingAttacked(11, 999);
        robot2.actWhenBeingAttacked(10, 999);
        robot2.actWhenBeingAttacked(9, 999);

        robot2.actWhenEnemyFallingBack(501);
        robot2.actWhenEnemyFallingBack(500);
        robot2.actWhenEnemyFallingBack(499);

        robot2.actWhenDeadEnd();
    }
}
