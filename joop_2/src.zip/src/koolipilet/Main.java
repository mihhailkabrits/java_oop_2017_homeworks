
package koolipilet;

/**
 * The type Main.
 */
//main
public class Main {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {

        DoorLock reaal = new DoorLock("REAAL");
        System.out.println(reaal.controlStatus("511111111111111111111"));

        DoorLock karlda = new DoorLock("KARLDA");
        System.out.println(karlda.controlStatus("4111111111111111111"));

        DoorLock kardla = new DoorLock("KARDLA");
        System.out.println(kardla.controlStatus("622222222223333333"));

        DoorLock kapak = new DoorLock("KAPAK");
        System.out.println(kapak.controlStatus("522222222222222222"));

        DoorLock noo = new DoorLock("NOO");
        System.out.println(noo.controlStatus("523233333333333333"));
        System.out.println(noo.controlStatus("11111111111111111115"));


    }
}
