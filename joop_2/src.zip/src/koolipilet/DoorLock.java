package koolipilet;

/**
 * The type Door lock.
 */
public class DoorLock {


        private String koolitunnus;
        private String isikukood;
        private StudentControl studentControl;

    /**
     * Instantiates a new Door lock.
     *
     * @param koolitunnus the koolitunnus
     */
    public DoorLock(String koolitunnus){
            this.koolitunnus = koolitunnus;
            this.studentControl = new StudentControl();
        }

    /**
     * Control status boolean.
     *
     * @param isikukood the isikukood
     * @return the boolean
     */
    public String controlStatus(String isikukood) {
            if (studentControl.controlStatus(koolitunnus, isikukood)) {
                System.out.print("(saab sisse) ");
            }
            else {
                System.out.print("(ei saa sisse) ");
            }
            return koolitunnus + "," + isikukood;

        }
    }
