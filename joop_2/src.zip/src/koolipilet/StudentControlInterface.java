package koolipilet;

/**
 * The interface Student control interface.
 */
public interface StudentControlInterface {
    /**
     * Control status boolean.
     *
     * @param koolitunnus the koolitunnus
     * @param isikukood   the isikukood
     * @return the boolean
     */
    boolean controlStatus(String koolitunnus, String isikukood);

}
