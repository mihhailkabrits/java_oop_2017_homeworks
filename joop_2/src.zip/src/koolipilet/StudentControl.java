package koolipilet;

/**
 * The type Student control.
 */
public class StudentControl implements StudentControlInterface {


    @Override
    public boolean controlStatus(String koolitunnus, String isikukood) {
        if (koolitunnus.equals("MHG") || koolitunnus.equals("KARDLA")
                || koolitunnus.equals("NOO") || koolitunnus.equals("REAAL")) {

            String firstNumber = isikukood.substring(0,1);
            if (firstNumber.equals("5") || firstNumber.equals("6")) {

                return true;
            }
        }

        return false;
    }

    }


