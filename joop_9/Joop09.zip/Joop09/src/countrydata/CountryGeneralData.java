package countrydata;

public class CountryGeneralData {
    private final String countryName;
    private final boolean isMemberOfEU;
    private final int area;

    public CountryGeneralData(String countryName, boolean isMemberOfEU, int area) {
        this.countryName = countryName;
        this.isMemberOfEU = isMemberOfEU;
        this.area = area;
    }

    public String getCountryName() {
        return countryName;
    }

    public boolean isMemberOfEU() {
        return isMemberOfEU;
    }

    public int getArea() {
        return area;
    }
}
