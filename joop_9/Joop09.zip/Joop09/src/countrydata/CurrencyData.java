package countrydata;

public class CurrencyData {
    private final String longName;
    private final String shortName;

    public CurrencyData(String longName, String shortName) {
        this.longName = longName;
        this.shortName = shortName;
    }

    public String getLongName() {
        return longName;
    }

    public String getShortName() {
        return shortName;
    }
}
