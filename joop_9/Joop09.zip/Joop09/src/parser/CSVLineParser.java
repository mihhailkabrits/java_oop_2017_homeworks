package parser;

import java.util.ArrayList;
import java.util.List;

public class CSVLineParser {
    public String[] splitCSVLine(String line) {
        List<String> elements = new ArrayList<>();

        boolean ignoreComas = false;

        int startIndex = 0;
        for (int i = 0; i < line.length(); i++) {
            if (line.substring(i, i + 1).equals("\"")) {
                startIndex = i + 1;
                ignoreComas = !ignoreComas;
            }

            if (line.substring(i, i + 1).equals(",") && !ignoreComas) {
                elements.add(line.substring(startIndex, i));
                startIndex = i + 1;
            }

            if (i == line.length() - 1) {
                elements.add(line.substring(startIndex));
            }
        }

        String[] elementsArray = new String[elements.size()];
        elements.toArray(elementsArray);
        return elementsArray;
    }
}
