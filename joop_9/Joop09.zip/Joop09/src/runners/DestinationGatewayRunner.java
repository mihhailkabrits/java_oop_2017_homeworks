package runners;

import destination.Destination;
import destination.DestinationGateway;
import parser.CSVLineParser;

import java.io.IOException;
import java.util.DoubleSummaryStatistics;
import java.util.List;

public class DestinationGatewayRunner {
    public static void main(String[] args) throws IOException {
        List<Destination> destinations = new DestinationGateway(new CSVLineParser())
                .getDestinationsFromCSVFile("states.csv");

        DoubleSummaryStatistics statistics = destinations.stream()
                .filter(s -> s.getGDPPerCapita() != Integer.MIN_VALUE)
                .mapToDouble(Destination::getGDPPerCapita)
                .summaryStatistics();
        System.out.println(String.format("Kõikide riikide keskmine SKP inimese kohta: %.02f", statistics.getAverage()));

        DoubleSummaryStatistics euroCountriesStatistics = destinations.stream()
                .filter(d -> d.getCurrencyShortName().toLowerCase().equals("eur"))
                .filter(d -> d.getGDPPerCapita() != Integer.MIN_VALUE)
                .mapToDouble(Destination::getGDPPerCapita)
                .summaryStatistics();
        System.out.println(String.format("Eurot kasutavate keskmine SKP inimese kohta: %.02f",
                euroCountriesStatistics.getAverage()));
        System.out.println(String.format("Eurot kasutavate minimaalne SKP inimese kohta: %.02f",
                euroCountriesStatistics.getMin()));
        System.out.println(String.format("Eurot kasutavate maksimaalne SKP inimese kohta: %.02f",
                euroCountriesStatistics.getMax()));

        final int MAX_AREA_FOR_COUNTING = 100_000;
        long differentCurrenciesNumber = destinations.stream()
                .filter(d -> d.getArea() < MAX_AREA_FOR_COUNTING)
                .map(Destination::getCurrencyShortName)
                .distinct()
                .count();
        System.out.println("Alla 100 000 km2 pindalaga riikides kasutusel olevate erinevate valuutade arv: "
                + differentCurrenciesNumber);

        final double KELVIN_TO_REAUMUR_VALUE = 273.15;
        final double REAUMUR_SCALE_VALUE = (double) 4 / 5;
        DoubleSummaryStatistics temperatureStatistics = destinations.stream()
                .mapToDouble(d -> (d.getAverageKelvin() - KELVIN_TO_REAUMUR_VALUE) * REAUMUR_SCALE_VALUE)
                .summaryStatistics();
        System.out.println(String.format("Kõikide riikide keskmine temperatuur Réaumur’i skaalal: %.02f",
                temperatureStatistics.getAverage()));
    }
}
