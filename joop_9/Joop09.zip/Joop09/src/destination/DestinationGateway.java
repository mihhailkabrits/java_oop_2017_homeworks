package destination;

import countrydata.CountryGeneralData;
import countrydata.CurrencyData;
import parser.CSVLineParser;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

public class DestinationGateway {
    private final CSVLineParser lineParser;

    public DestinationGateway(CSVLineParser parser) {
        this.lineParser = parser;
    }

    public List<Destination> getDestinationsFromCSVFile(String fileName) throws IOException {
        final int NAME_INDEX = 0;
        final int EU_MEMBER_INDEX = 1;
        final int AREA_INDEX = 12;
        final int LONG_CURRENCY_INDEX = 8;
        final int SHORT_CURRENCY_INDEX = 9;
        final int ACCESSION_YEAR_INDEX = 2;
        final int CAPITAL_INDEX = 16;

        return Files.lines(FileSystems.getDefault().getPath(fileName))
                .skip(1)
                .map(s -> {
                    String[] splittedLine = lineParser.splitCSVLine(s);

                    CountryGeneralData countryGeneralData = new CountryGeneralData(splittedLine[NAME_INDEX],
                            splittedLine[EU_MEMBER_INDEX].toLowerCase().equals("member"),
                            parseNumberString(splittedLine[AREA_INDEX]));
                    CurrencyData currencyData = new CurrencyData(splittedLine[LONG_CURRENCY_INDEX],
                            splittedLine[SHORT_CURRENCY_INDEX]);

                    int accessionYear = parseNumberString(splittedLine[ACCESSION_YEAR_INDEX]);
                    int gdpPerCapita = parseNumberString(splittedLine[CAPITAL_INDEX]);

                    return new Destination(countryGeneralData, accessionYear, currencyData, gdpPerCapita);
                })
                .collect(Collectors.toList());
    }

    private static int parseNumberString(String line) {
        try {
            return Integer.parseInt(line);
        } catch (NumberFormatException ignored) {
            return Integer.MIN_VALUE;
        }
    }
}
