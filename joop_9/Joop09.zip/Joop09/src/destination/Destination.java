package destination;

import countrydata.CountryGeneralData;
import countrydata.CurrencyData;

import java.io.Serializable;

public class Destination implements Serializable {
    private CountryGeneralData countryGeneralData;
    private int accessionYear;
    private CurrencyData currencyData;
    private int gdpPerCapita;

    public Destination() {

    }

    Destination(CountryGeneralData countryGeneralData, int accessionYear, CurrencyData currencyData,
                int gdpPerCapita) {
        this.countryGeneralData = countryGeneralData;
        this.accessionYear = accessionYear;
        this.currencyData = currencyData;
        this.gdpPerCapita = gdpPerCapita;
    }

    public String getCountryName() {
        return countryGeneralData.getCountryName();
    }

    public boolean isEuropeanUnionMember() {
        return countryGeneralData.isMemberOfEU();
    }

    public double getAverageKelvin() {
        final double DEFAULT_TEMP_OF_NON_EU_COUNTRY = 299;
        return countryGeneralData.isMemberOfEU() ? (double) accessionYear / 100 + 273 : DEFAULT_TEMP_OF_NON_EU_COUNTRY;
    }

    public String getCurrencyLongName() {
        return currencyData.getLongName();
    }

    public String getCurrencyShortName() {
        return currencyData.getShortName();
    }

    public int getGDPPerCapita() {
        return gdpPerCapita;
    }

    public int getArea() {
        return countryGeneralData.getArea();
    }
}
